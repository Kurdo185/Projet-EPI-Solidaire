
  <!-- Division pour le pied de page -->
<div/>
	<p>
	</p>
	<img src = "./images/img.jpg" id = "pharesGecet" alt = "Phares de Getcet" title = "Phares de Getcet"  height = "200" width = "100%"/>
	<div id = "piedP">	@Mairie de Getcet S/Mer</div>

  </body>
</html>


