
<ul>
<?php
	  $nom = $_SESSION['nom'];
      echo "Bonjour $nom <a href='Deconnexion.php' >Deconnexion</a>";

?>
</ul>
