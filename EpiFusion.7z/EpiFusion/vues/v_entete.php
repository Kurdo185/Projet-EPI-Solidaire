﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml11.dtd">
	   
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">

	<head>
		<title>Intranet de la mairie de GETCET sur Mer</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link href="./styles/styles.css" rel="stylesheet" type="text/css" />
		<link rel="icon" type="image/png" href="logo.png" />
		<link rel="icon" href="Getcet.ico" />
	</head>
  
	<body>

			<div id="entete">
				<div id = "enteteG"><img src="./images/LogoGetcet.png" id = "logoGecet" alt = "Mairie de Getcet" title = "Mairie de Getcet" width = "200" heigth = "200"/></div>
				<div id = "enteteD">
					Intranet de la Mairie de GETCET S/MER

				</div>

			</div>
			<div id = "TitreApp">EPI'Solidaire</div>
	  
	  
